print("Python is Easy")
