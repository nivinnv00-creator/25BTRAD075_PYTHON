print("*******")
print("*******")
print("*******")
