name = "Nivin"
print(name)
