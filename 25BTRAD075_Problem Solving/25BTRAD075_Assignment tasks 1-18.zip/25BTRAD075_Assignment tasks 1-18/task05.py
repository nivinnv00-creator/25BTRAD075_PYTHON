print("Computer\nScience\nEngineering")
