name = input("Enter name: ")
age = int(input("Enter age: "))
cgpa = float(input("Enter CGPA: "))
print(f"My name is {name}. I am {age} years old and my CGPA is {cgpa}.")
