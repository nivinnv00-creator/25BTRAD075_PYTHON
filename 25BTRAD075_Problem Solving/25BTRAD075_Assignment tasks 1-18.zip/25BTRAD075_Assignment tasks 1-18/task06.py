print("Name\tAge\tCity")
